avatar-1024.png          主用：上传头像用这张（1024x1024，微信要求>=300）
avatar-512.png / -256.png 同图低分辨率版
avatar-alt-guang-1024.png 备用方案，仅大尺寸场合（封面/名片/公众号头图）
